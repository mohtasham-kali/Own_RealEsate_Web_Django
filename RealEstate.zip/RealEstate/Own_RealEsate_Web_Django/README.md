# Own_RealEsate_Web_Django


admin username && password:

usr_name = hacker-iot

pwd = #K********123
