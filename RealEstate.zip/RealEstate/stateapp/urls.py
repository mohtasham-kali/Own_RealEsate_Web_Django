from django.contrib import admin
from django.urls import path, include
from stateapp import views

urlpatterns = [
    path("index", views.index, name='stateapp'),
    path("about", views.about, name='stateapp'),
    path("blog_grid", views.blog_grid, name='stateapp'),
    path("blog_single", views.blog_single, name='stateapp'),
    path("agents_grid", views.agents_grid, name='stateapp'),
    path("agents_single", views.agents_single, name='stateapp'),
    path("property_grid", views.property_grid, name='stateapp'),
    path("property_single", views.property_single, name='stateapp'),
    path("contact", views.contact, name='stateapp')
]