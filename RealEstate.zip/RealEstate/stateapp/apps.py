from django.apps import AppConfig


class StateappConfig(AppConfig):
    name = 'stateapp'
