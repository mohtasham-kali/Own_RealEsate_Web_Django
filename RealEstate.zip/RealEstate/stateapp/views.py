from django.shortcuts import render, HttpResponse

# Create your views here.

def index(request):
    return render(request, 'index.html')
    # return HttpResponse("")
def about(request):
    return render(request, 'about.html')

def blog_grid(request):
    return render(request, 'blog-grid.html')

def blog_single(request):
    return render(request, 'blog-single.html')

def agents_grid(request):
    return render(request, 'agents-grid.html')

def agents_single(request):
    return render(request, 'agents-single.html')

def property_grid(request):
    return render(request, 'property-grid.html')

def property_single(request):
    return render(request, 'property-single.html')

def contact(request):
    return render(request, 'contact.html')
